<?php
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'id12622564_banco');
	define('DB_USER', 'id12622564_banco');
	define('DB_PASS', 'banco2019');
?>
